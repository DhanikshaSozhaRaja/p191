AFRAME.registerComponent('drive',{
    init:function(){
        var gameStateVal = this.el.getAttribute("game");
        if(gameStateVal == 'play'){
        this.driveCar();
        };
    },
    driveCar:function(){
        var multiply = 10
        var wheelRotation = 0
        window.addEventListener('keydown', function(e){
            var wheel = document.querySelector('#wEntity')
            if(e.code == "ArrowRight" && wheelRotation > -40){
                wheelRotation -= 5
                wheel.setAttribute("rotation", {x:90, y:0, z:wheelRotation})
            }
            if(e.code == "ArrowLeft" && wheelRotation < 40){
                wheelRotation += 5
                wheel.setAttribute("rotation", {x:90, y:0, z:wheelRotation})
            }
            var camera1 = document.querySelector("#camera_1")
            var cameraRotation=camera1.getAttribute("rotation")
            var cameraPosition=camera1.getAttribute("position")
            var cameraMovementControl = camera1.getAttribute("movement-controls")
            console.log("speed", cameraMovementControl.speed)
            camera1.setAttribute("movement-controls", {"speed": cameraMovementControl.speed+ 0.005})
            var cameraDirection = new THREE.Vector3(); 
            camera1.object3D.getWorldDirection(cameraDirection); 
            if (e.code == "ArrowRight") { 
                cameraRotation.y -= 5 
                 camera1.setAttribute("rotation", { x: 0, y: cameraRotation.y, z: 0 }) 
                camera1.setAttribute("movement-controls", {"speed": cameraMovementControl.speed+ 0.005})
                }
             if (e.code == "ArrowLeft") { 
                cameraRotation.y += 5
                camera1.setAttribute("rotation", { x: 0, y: cameraRotation.y, z: 0 }) 
                 camera1.setAttribute("movement-controls", {"speed": cameraMovementControl.speed+ 0.005})
                }
                if (e.code == "ArrowUp") { 
                    console.log(cameraMovementControl.speed)
                    multiply += 0.5
                if (multiply <= 100 && cameraPosition.z > -500) { 
                    camera1.setAttribute("movement-controls", {"speed": cameraMovementControl.speed + 0.005})
                    var accelerateCar = document.querySelector("#acc") 
                    accelerateCar.setAttribute("material", "color", "green")
                    var carSpeed = document.querySelector("#speed")
                    carSpeed.setAttribute("text", {value:multiply})
             } }
             if (e.code == "Space") { 
                camera1.setAttribute("movement-controls", {"speed": 0}) 
                var stopCar = document.querySelector("#br") 
                stopCar.setAttribute("material", "color", "red") }
            
                window.addEventListener('keyup', function (e) { 
                    var camera1 = document.querySelector("#camera_1") 
                    var cameraDirection = new THREE.Vector3(); 
                    camera1.object3D.getWorldDirection(cameraDirection);
                     var cameraMoveControl = camera1.getAttribute("movement-controls")
                      if (e.code == "Space") { 
                        var startCar = document.querySelector("#br") 
                        startCar.setAttribute("material", "color", "gray") 
                    } 
                    if (e.code== "ArrowUp") { 
                        if (multiply > 10) { 
                            multiply -= 0.5 
                              camera1.setAttribute("movement-controls", {"speed": cameraMoveControl.speed + 0.005})

                    } 
                var accelerateCar = document.querySelector("#acc") 
                accelerateCar.setAttribute("material", "color", "gray") } })
        })
    }

})